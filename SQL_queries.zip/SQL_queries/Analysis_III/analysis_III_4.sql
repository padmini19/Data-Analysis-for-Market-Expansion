----------------- CTE 1 -------------------
with no_of_orders as (
	select 
	customer_id,
	count(customer_id)as no_of_orders
	from 
	orders
	group by customer_id)
	
----------------- MAIN QUERY -------------------
select 
	case
		when no_of_orders in (1,2) then 'Occasional'
		when no_of_orders in (3,4,5)then 'Regular'
		else 'Loyal'
		end as customer_type,
	count(*) as count	
from 
	no_of_orders
group by 
	customer_type
	

