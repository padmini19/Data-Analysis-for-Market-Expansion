---------------------------- CTE 1 ---------------------------
with m_sales as (
select 
	oi.product_id,
	TO_CHAR(o.order_purchase_timestamp, 'yyyy-mm')as sale_month,
	sum(oi.price) as monthly_sales
from orders o
join order_items oi
on o.order_id=oi.order_id
group by
	sale_month,
	product_id		
)
------------------------------ MAIN QUERY -------------------------------
select 
	product_id,
	sale_month,
	monthly_sales,
	sum(monthly_sales) over(partition by product_id order by sale_month) as total_sales
from m_sales
order by product_id,sale_month;
