-------------------- CTE 1 ----------------------
with pro_quantity as(
	select 
		product_id,
		count(product_id) as total_quantity_sold
	from order_items
	group by product_id
)
----------------- MAIN QUERY -------------------
select 
	product_id,
	total_quantity_sold
from 
	pro_quantity
where 
total_quantity_sold>
	(select
	round(avg(total_quantity_sold)) as overall_average
	from pro_quantity)
order by 
	total_quantity_sold desc;
