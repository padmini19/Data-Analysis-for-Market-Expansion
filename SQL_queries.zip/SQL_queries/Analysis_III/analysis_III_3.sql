select 
    to_char(order_purchase_timestamp, 'Month') as month,
    sum(price) as total_revenue
from orders
join order_items 
	on orders.order_id = order_items.order_id
where 
    extract(year from order_purchase_timestamp) = 2018
group by
    month,
	extract(month from order_purchase_timestamp)
order by 
     extract(month from order_purchase_timestamp) asc;




