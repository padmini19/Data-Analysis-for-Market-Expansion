---------------------------- CTE 1 ---------------------------
with monthly_sales as (
select
	p.payment_type,
	TO_CHAR(o.order_purchase_timestamp, 'yyyy-mm')as sale_month,
	sum(oi.price) as monthly_total	
from orders o
join order_items oi
  	on o.order_id = oi.order_id
join payments p
	on o.order_id = p.order_id	
where
	extract(year from order_purchase_timestamp) = 2018	
group by 
	payment_type,
	sale_month
),
------------------------------ CTE 2 -------------------------------
previous_mon_sales as(
select 
	payment_type,
	sale_month,
	monthly_total,
	lag(monthly_total) over (partition by payment_type order by sale_month) as previous_value
from monthly_sales)

----------------------------- MAIN QUERY ----------------------------------
select
	payment_type, 
	sale_month, 
	monthly_total, 
	round((monthly_total-previous_value)* 100/previous_value,2) as monthly_change
from previous_mon_sales;