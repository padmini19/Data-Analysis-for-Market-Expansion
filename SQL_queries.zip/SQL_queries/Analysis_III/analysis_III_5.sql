select 
    customer_id, 
    round(avg(price)) as avg_order_value, 
    rank() over (order by avg(price) desc) as customer_rank 
from 
    orders o
join 
    order_items oi on o.order_id = oi.order_id 
group by 
    customer_id 
order by 
    avg_order_value desc 
limit 20;

	