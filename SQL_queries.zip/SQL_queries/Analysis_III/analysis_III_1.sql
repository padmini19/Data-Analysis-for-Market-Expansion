select
    case
        when extract(month from o.order_purchase_timestamp) in (3, 4, 5) then 'Spring'
        when extract(month from o.order_purchase_timestamp) in (6, 7, 8) then 'Summer'
        when extract(month from o.order_purchase_timestamp) in (9, 10, 11) then 'Autumn'
        else 'Winter'
    end as season,
    sum(oi.price) as total_sales
from
    orders o
join
    order_items oi 
	on oi.order_id = o.order_id
group by
    season
order by
    total_sales desc;




	