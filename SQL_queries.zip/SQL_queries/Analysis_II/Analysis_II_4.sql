select
	customer_id,
		case
 		when count(customer_id)=1 then 'New'
		when count(customer_id) between 2 and 4 then 'Returning'
		else 'loyal'
	end as customer_type
from orders o
group by customer_id;

 

 