select 
	distinct p.product_category_name,
	min(oi.price)over(partition by p.product_category_name)as min_price,
	max(oi.price)over(partition by p.product_category_name)as max_price,
	round(avg(oi.price)over(partition by p.product_category_name),2)as avg_price
from order_items oi
join product p
on oi.product_id=p.product_id
order by avg_price desc;

