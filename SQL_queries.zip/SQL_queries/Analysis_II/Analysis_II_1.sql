select 
	case
		when payment_value< 200 then 'Low'
		when payment_value between 200 and 1000 then 'Medium'
		else 'High'
	end as order_value_segment,
	payment_type,
	count(payment_type)as count
from payments 
group by 
	order_value_segment,
	payment_type
order by count desc;
