select
	c.customer_unique_id,
	count(c.customer_unique_id)as total_orders
from customers c
join orders o
on c.customer_id=o.customer_id
group by c.customer_unique_id
having count(c.customer_unique_id)>1
order by total_orders desc;