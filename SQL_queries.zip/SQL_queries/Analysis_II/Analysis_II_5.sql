select
	p.product_category_name as product_category,
	sum(oi.price) as total_revenue
from order_items oi
join product p
on oi.product_id=p.product_id
group by product_category
order by total_revenue desc
limit 5;

