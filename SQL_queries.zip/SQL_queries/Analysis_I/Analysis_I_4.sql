select 
	to_char(o.order_purchase_timestamp,'Month')as Month,
	round(sum(oi.price))as total_sales
from orders o
join order_items oi
on o.order_id=oi.order_id
group by month
order by total_sales desc
limit 3;