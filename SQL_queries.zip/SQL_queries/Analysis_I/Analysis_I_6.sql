select 
	payment_type,
	round(stddev(payment_value),2) as  std_deviation
from payments
group by payment_type
order by std_deviation asc;
