select 
	p.product_category_name,
	max(oi.price)-min(oi.price)as price_difference
from order_items oi
join product p
on oi.product_id=p.product_id
group by p.product_category_name
having max(oi.price)-min(oi.price)> 500
order by price_difference desc;

