select 
	oi.product_id,
	oi.price
from order_items oi
join product p
on oi.product_id=p.product_id
where 
	p.product_category_name like '%smart%'
	and
	oi.price between 100 and 500
order by oi.price desc;