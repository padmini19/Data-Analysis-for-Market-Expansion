select 
	payment_type,
	round(count(payment_type)*100/sum(count(payment_type))over(),1)as percentage_orders
from payments 
group by payment_type
order by percentage_orders desc;