select
	payment_type,
	round(avg(payment_value)) as rounded_avg_payment
from payments	
group by payment_type
order by payment_type,rounded_avg_payment;
	