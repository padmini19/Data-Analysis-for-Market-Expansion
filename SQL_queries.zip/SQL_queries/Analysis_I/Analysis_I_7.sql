select 
	product_id,
	product_category_name
from product
where 
	product_category_name is null or 
	product_category_name like '_'	
order by product_category_name, product_id; 